from django.core.management.base import BaseCommand
from nuraram.models import Client
from django.utils import timezone

class Command(BaseCommand):
    help = 'Populate Clients table with sample data'

    def handle(self, *args, **options):
        for i in range(1, 8):
            client = Client(
                surname=f'Иванов{i}',
                name=f'Иван{i}',
                age=i * 10,
                deposit=10000 * i,
                created_at=timezone.now(),
            )
            client.save()

        self.stdout.write(self.style.SUCCESS('Table powpulated successfully!'))
