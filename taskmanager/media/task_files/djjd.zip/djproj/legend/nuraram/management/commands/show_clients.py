from django.core.management.base import BaseCommand
from nuraram.models import Client

class Command(BaseCommand):
    help = 'Show Clients data'

    def handle(self, *args, **options):
        clients = Client.objects.all()
        for client in clients:
            self.stdout.write(self.style.SUCCESS(f'Name: {client.name}, Surname: {client.surname}, Age: {client.age}, Deposit: {client.deposit}'))
