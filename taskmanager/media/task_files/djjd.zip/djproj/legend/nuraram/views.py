from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from nuraram.models import Client
from .forms import UserForm
from django.utils import timezone

def user_add(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            # Получаем данные из формы
            name = form.cleaned_data['name']
            surname = form.cleaned_data['surname']
            age = form.cleaned_data['age']
            credit = form.cleaned_data.get('credit', False)
            mortgage = form.cleaned_data.get('mortgage', False)
            gender = form.cleaned_data.get('gender', '')

            # Отправляем пользователя на страницу "success.html" с данными
            return render(request, "success.html", {
                'name': name,
                'surname': surname,
                'age': age,
                'credit': credit,
                'mortgage': mortgage,
                'gender': gender,
            })

    else:
        form = UserForm()

    return render(request, "net.html", {"form": form})

def index(request):
    return render(request, 'index.html')
