from django import forms
from django.core.validators import MinValueValidator, MaxValueValidator

class UserForm(forms.Form):
    name = forms.CharField(label='Имя', max_length=30, required=True)
    surname = forms.CharField(label='Фамилия', max_length=30, required=True)
    age = forms.IntegerField(label='Возраст', required=True, validators=[MinValueValidator(18, 'Минимальный возраст - 18 лет'), MaxValueValidator(63, 'Максимальный возраст - 63 года')])
    имеет_кредит = forms.BooleanField(required=False, initial=True)
    имеет_ипотека = forms.BooleanField(required=False, initial=False)
    пол = forms.ChoiceField(choices=[('', ''), ('M', 'Мужской'), ('F', 'Женский')], required=False, initial='')

