from django.test import TestCase
from django.urls import reverse

class TestIndex(TestCase):
    def test_index(self):
        url = reverse('index')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_text(self):
        url = reverse('index')
        response = self.client.get(url)
        self.assertIn('Главная страница', response.content.decode())
