from django.urls import path
from nuraram import views
from django.contrib import admin


urlpatterns = [
    path("", views.index, name='index'),
    path('admin/', admin.site.urls),
    # path("about", views.about),
    # path("contact", views.contact)
    # path("postuser/", views.postuser),
    path('user_add/', views.user_add, name='user_add'),
]
